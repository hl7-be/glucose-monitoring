# hl7.fhir.be.glucose-monitoring#1.0.0: HL7 FHIR Implementation Guide: Glucose Monitoring(en)

## Pages

* [Glucose Monitoring](index.md)
* [Changes](changes.md)
* [Spec](spec.md)
* [Artifacts Summary](artifacts.md)
* [Downloads](downloads.md)
* [Guidance](guidance.md)

## Resources

### ValueSets

* [BeVSDiabetesObservationCategory](ValueSet-be-vs-diabetes-observation-category.md)
* [BeVSDiabetesObservationCode](ValueSet-be-vs-diabetes-observation-code.md)
* [BeVSDiabetesObservationStatus](ValueSet-be-vs-diabetes-observation-status.md)
* [BeVSDiabetesReportCategory](ValueSet-be-vs-diabetes-report-category.md)
* [BeVSDiabetesReportCode](ValueSet-be-vs-diabetes-report-code.md)
* [BeVSDiabetesReportStatus](ValueSet-be-vs-diabetes-report-status.md)

### Logicals

* [BeModelDiagnosticReportDiabetes](StructureDefinition-BeModelDiagnosticReportDiabetes.md)
* [BeModelObservationDiabetes](StructureDefinition-BeModelObservationDiabetes.md)

### Resource Profiles

* [BeDiagnosticReportDiabetes](StructureDefinition-be-diagnostic-report-diabetes.md)
* [BeObservationDiabetes](StructureDefinition-be-observation-diabetes.md)

### ImplementationGuides

* [HL7 FHIR Implementation Guide: Glucose Monitoring](ImplementationGuide-hl7.fhir.be.glucose-monitoring.md)

### NamingSystems

* [BeNSDiabetesDeviceType](NamingSystem-be-ns-diabetes-device-type.md)
* [BeNSDiagnosticReportDiabetes](NamingSystem-be-ns-diagnostic-report-diabetes.md)
* [BeNSObservationDiabetes](NamingSystem-be-ns-observation-diabetes.md)

### Examples

* [uc52-bundle (Bundle)](Bundle-uc52-bundle.md)
* [uc53-bundle (Bundle)](Bundle-uc53-bundle.md)
* [Diabetes device report (Composition)](Composition-uc52-composition.md)
* [Diabetes device report (Composition)](Composition-uc53-composition.md)
* [device (Device)](Device-device.md)
* [uc52-pdfonly (DiagnosticReport)](DiagnosticReport-uc52-pdfonly.md)
* [uc53-pdf-derived (DiagnosticReport)](DiagnosticReport-uc53-pdf-derived.md)
* [397dffb4-a88a-47d0-b10d-beffcbf6157d (Observation)](Observation-397dffb4-a88a-47d0-b10d-beffcbf6157d.md)
* [449a728d-dfb4-422d-94aa-1a2d43849ee5 (Observation)](Observation-449a728d-dfb4-422d-94aa-1a2d43849ee5.md)
* [454a29d0-0893-458a-b2e5-25452b89e29a (Observation)](Observation-454a29d0-0893-458a-b2e5-25452b89e29a.md)
* [6756477d-b57a-4611-b048-374d46f52908 (Observation)](Observation-6756477d-b57a-4611-b048-374d46f52908.md)
* [a6665182-e11a-40a9-ae83-9b093a353f16 (Observation)](Observation-a6665182-e11a-40a9-ae83-9b093a353f16.md)
* [b28ef33b-0480-4bde-a5df-94988813110b (Observation)](Observation-b28ef33b-0480-4bde-a5df-94988813110b.md)
* [b44fe5d5-f57b-4424-b628-d2baeb447738 (Observation)](Observation-b44fe5d5-f57b-4424-b628-d2baeb447738.md)
* [c611b58d-27bb-49e2-b3ec-bd59e986f5f3 (Observation)](Observation-c611b58d-27bb-49e2-b3ec-bd59e986f5f3.md)
* [terminology-expansion (Parameters)](Parameters-terminology-expansion.md)
